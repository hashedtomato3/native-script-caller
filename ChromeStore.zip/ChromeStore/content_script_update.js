// Copyright (C) 2020 hashedtomato3@gmail.com
// License: MIT 


{
  //console.log("loading content_script_update.js")
  chrome.runtime.sendMessage({cmd:"setup"});
}
