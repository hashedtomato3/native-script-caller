function chromeTabsSendMessage(tabId, message) {
    return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, message, {}, (response) => {
            if (chrome.runtime.lastError) {
                return reject(chrome.runtime.lastError);
            }
            resolve(response);
        });
    });
}
    
document.querySelector("#btn").addEventListener("click", async function() {
    console.info("creating tab for sandbox page")
    // create tab of sandbox page
    const url = chrome.runtime.getURL("sandbox_page.html")
    const tab = await chrome.tabs.create({url: url});
    console.log(tab)
    // wait for load page
    for(let i=0; i<30; i++){
    await new Promise(resolve => setTimeout(resolve, 200));
    let [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    console.log(t.status)
    if( t.status === "complete" ) {
    console.log("break at: "+i)
    break;
    }
    }
    // send message to sandbox_page
    const msg = {js:"function SandboxScriptFunction(indata){return 'result: '+indata}", indata:"abcde"}
      console.info("send message to sandbox page:")
    console.log(msg);
    const sandboxPageResults = await chromeTabsSendMessage(tab.id, msg);
      console.info("return value from sandbox page:");
    console.log(sandboxPageResults);
    // check error in injection code
    if(sandboxPageResults.error){
    throw sandboxPageResults; // return error
    }
    // close tab
    
    });